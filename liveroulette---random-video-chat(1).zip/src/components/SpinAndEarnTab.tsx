import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { Disc, Coins, Sparkles, AlertCircle, Trophy, CheckCircle2 } from 'lucide-react';

export const REWARDS = [
  { coins: 50, color: '#f59e0b', label: '50 Coins' },
  { coins: 100, color: '#ec4899', label: '100 Coins' },
  { coins: 200, color: '#3b82f6', label: '200 Coins' },
  { coins: 400, color: '#8b5cf6', label: '400 Coins' },
  { coins: 500, color: '#10b981', label: '500 Coins' }
] as const;

export const SpinAndEarnTab: React.FC = () => {
  const {
    spinCount,
    spinsRemaining,
    prepareSpin,
    commitSpinReward,
    canSpin,
    currentUser,
    resetSpinCounterForTesting
  } = useApp();

  const [isSpinning, setIsSpinning] = useState(false);
  const [rotationDegree, setRotationDegree] = useState(0);
  const [wonPrize, setWonPrize] = useState<{ amount: number; message: string } | null>(null);

  const numSlices = REWARDS.length;
  const sliceDeg = 360 / numSlices; // 72 degrees each

  const handleSpinClick = () => {
    // STRICT GUARD CLAUSE: Prevent spinning if 5 spins are already used or currently spinning
    if (spinCount >= 5 || isSpinning) return;

    setWonPrize(null);
    setIsSpinning(true);

    // 1. Prepare spin: Deduct 1 daily spin and get the exact prize & slice index
    const result = prepareSpin();
    if (!result) {
      setIsSpinning(false);
      return;
    }

    const exactRewardCoins = result.prize;
    const targetSliceIndex = result.index;

    // 2. Exact visual pointer landing calculation:
    // Slices are rendered in order [0: 50, 1: 100, 2: 200, 3: 400, 4: 500]
    // The slice label is rotated by `targetSliceIndex * sliceDeg + sliceDeg / 2`.
    // At rotation 0, angle 0 is at 12 o'clock (top).
    // To rotate target slice's center to the top (0 degrees):
    // When the wheel rotates clockwise by R degrees, the slice at angle A moves to (A + R) mod 360.
    // For that slice to end up at 0 deg (or 360 deg), we need (A + R) = k * 360  =>  R = 360 - A.
    const sliceCenterAngle = targetSliceIndex * sliceDeg + sliceDeg / 2;
    const extraFullRotations = 6 * 360; // 6 full turns for smooth visual effect
    const currentModulo = rotationDegree % 360;
    const neededOffset = (360 - sliceCenterAngle) - currentModulo;
    const normalizedOffset = ((neededOffset % 360) + 360) % 360;
    const nextTotalDegree = rotationDegree + extraFullRotations + normalizedOffset;

    setRotationDegree(nextTotalDegree);

    // 3. Exactly when wheel completes spinning animation (4000ms):
    // Commit the exact reward to the wallet balance synchronously with popup display
    setTimeout(() => {
      commitSpinReward(exactRewardCoins);
      setIsSpinning(false);
      setWonPrize({
        amount: exactRewardCoins,
        message: `Congratulations! You won ${exactRewardCoins} Coins!`
      });
    }, 4000);
  };

  return (
    <div className="w-full max-w-2xl mx-auto px-4 py-4 flex flex-col items-center select-none">
      {/* Header card */}
      <div className="text-center mb-4">
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs font-bold mb-2">
          <Sparkles className="w-3.5 h-3.5" />
          <span>Daily Lucky Spin Wheel</span>
        </div>
        <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
          Spin & Win Free Coins
        </h2>
        <p className="text-xs sm:text-sm text-neutral-400 mt-1 max-w-sm mx-auto">
          Spin the wheel every day to earn up to 500 Coins per spin. Auto-updates your balance instantly!
        </p>
      </div>

      {/* Daily Spins Remaining Status Badge: Spins Left Today: X/5 */}
      <div className="w-full max-w-sm bg-neutral-900 border border-neutral-800 rounded-2xl p-3 mb-5 flex items-center justify-between shadow-sm">
        <div className="flex items-center gap-2">
          <div className="w-8 h-8 rounded-xl bg-amber-500/20 text-amber-400 flex items-center justify-center">
            <Disc className="w-4 h-4" />
          </div>
          <div>
            <div className="text-xs font-bold text-white flex items-center gap-1.5">
              <span>Spins Left Today:</span>
              <span className="font-mono text-amber-300 font-black">{spinsRemaining}/5</span>
            </div>
            <div className="text-[11px] text-neutral-400">{spinCount}/5 used today • Resets daily</div>
          </div>
        </div>

        <div className="flex items-center gap-1">
          {[1, 2, 3, 4, 5].map((s) => (
            <span
              key={s}
              className={`w-4 h-4 rounded-full flex items-center justify-center text-[9px] font-black ${
                s <= spinsRemaining
                  ? 'bg-amber-400 text-neutral-900 shadow-xs'
                  : 'bg-neutral-800 text-neutral-600'
              }`}
            >
              {s}
            </span>
          ))}
        </div>
      </div>

      {/* INTERACTIVE SPIN WHEEL CONTAINER */}
      <div className="relative w-72 h-72 sm:w-80 sm:h-80 my-2 flex items-center justify-center">
        {/* Pointer / Needle at top */}
        <div className="absolute -top-3 z-30 flex flex-col items-center filter drop-shadow-lg pointer-events-none">
          <div className="w-0 h-0 border-l-[12px] border-l-transparent border-r-[12px] border-r-transparent border-t-[22px] border-t-rose-500" />
        </div>

        {/* Outer Wheel Ring with LED bulbs */}
        <div className="w-full h-full rounded-full p-2.5 bg-gradient-to-tr from-amber-600 via-neutral-900 to-rose-700 shadow-2xl border-4 border-amber-400/80 relative flex items-center justify-center">
          {/* Wheel Disc */}
          <div
            className="w-full h-full rounded-full overflow-hidden relative shadow-inner"
            style={{
              transform: `rotate(${rotationDegree}deg)`,
              transition: isSpinning
                ? 'transform 4s cubic-bezier(0.15, 0.9, 0.2, 1)'
                : 'none'
            }}
          >
            {/* Slices representation via SVG */}
            <svg viewBox="0 0 100 100" className="w-full h-full transform -rotate-90">
              {REWARDS.map((r, i) => {
                const startAngle = (i * sliceDeg * Math.PI) / 180;
                const endAngle = (((i + 1) * sliceDeg) * Math.PI) / 180;

                const x1 = 50 + 50 * Math.cos(startAngle);
                const y1 = 50 + 50 * Math.sin(startAngle);
                const x2 = 50 + 50 * Math.cos(endAngle);
                const y2 = 50 + 50 * Math.sin(endAngle);

                return (
                  <path
                    key={i}
                    d={`M50,50 L${x1},${y1} A50,50 0 0,1 ${x2},${y2} Z`}
                    fill={r.color}
                    stroke="#171717"
                    strokeWidth="1.5"
                  />
                );
              })}
            </svg>

            {/* Labels overlay placed on slices */}
            {REWARDS.map((r, i) => {
              const angle = i * sliceDeg + sliceDeg / 2;
              return (
                <div
                  key={i}
                  className="absolute inset-0 flex items-start justify-center pt-5 pointer-events-none"
                  style={{
                    transform: `rotate(${angle}deg)`,
                    transformOrigin: '50% 50%'
                  }}
                >
                  <span className="text-white font-black text-xs sm:text-sm tracking-wider drop-shadow-md flex items-center gap-0.5">
                    🪙 {r.coins}
                  </span>
                </div>
              );
            })}
          </div>

          {/* Center Hub Button */}
          <div className="absolute inset-0 m-auto w-20 h-20 rounded-full bg-neutral-900 border-4 border-amber-400 flex flex-col items-center justify-center shadow-xl z-20">
            <Coins className="w-5 h-5 text-amber-400" />
            <span className="text-[10px] font-black text-amber-300 uppercase mt-0.5">
              Lucky
            </span>
          </div>
        </div>
      </div>

      {/* Won Prize Banner */}
      {wonPrize && (
        <div className="mt-4 p-3 rounded-2xl bg-amber-500/20 border border-amber-400 text-center animate-bounce shadow-lg flex items-center gap-2">
          <Trophy className="w-5 h-5 text-amber-400 shrink-0" />
          <span className="text-sm font-black text-amber-200">{wonPrize.message}</span>
        </div>
      )}

      {/* Spin Action Button */}
      <div className="mt-5 w-full max-w-xs flex flex-col items-center gap-2">
        <button
          type="button"
          id="btn-spin-wheel-action"
          onClick={handleSpinClick}
          disabled={spinCount >= 5 || isSpinning}
          className={`w-full py-3.5 px-6 rounded-2xl font-black text-sm sm:text-base flex items-center justify-center gap-2 transition-all transform shadow-xl cursor-pointer ${
            spinCount < 5 && !isSpinning
              ? 'bg-gradient-to-r from-amber-400 via-amber-500 to-yellow-400 hover:from-amber-300 hover:to-yellow-300 text-neutral-950 active:scale-95 shadow-amber-500/25'
              : 'bg-neutral-800 text-neutral-500 cursor-not-allowed border border-neutral-700'
          }`}
        >
          <Disc className={`w-5 h-5 ${isSpinning ? 'animate-spin' : ''}`} />
          <span>
            {isSpinning
              ? 'Spinning Wheel...'
              : spinCount < 5
              ? `SPIN (${spinsRemaining} Left)`
              : 'Daily Limit Reached (0/5 Left)'}
          </span>
        </button>

        {spinCount >= 5 && (
          <div className="text-[12px] text-amber-300 font-medium flex items-center justify-center gap-1.5 mt-2 text-center bg-amber-500/10 border border-amber-500/30 px-3.5 py-2.5 rounded-xl w-full">
            <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
            <span>Daily limit reached! 5/5 spins used today. Try again tomorrow.</span>
          </div>
        )}

        {/* Temporary Test Reset Button */}
        <button
          type="button"
          id="btn-test-reset-spins"
          onClick={resetSpinCounterForTesting}
          className="mt-3 text-xs text-amber-400/90 hover:text-amber-300 underline font-medium cursor-pointer transition flex items-center gap-1"
        >
          <Sparkles className="w-3 h-3" />
          <span>Reset Spin Counter (Get 5 Fresh Spins for Testing)</span>
        </button>
      </div>

      {/* Reward tier preview chips */}
      <div className="mt-6 w-full max-w-sm bg-neutral-900/60 border border-neutral-800 rounded-2xl p-3">
        <div className="text-[11px] font-bold text-neutral-400 mb-2 uppercase tracking-wider text-center">
          Possible Rewards in this Wheel
        </div>
        <div className="grid grid-cols-5 gap-1.5 text-center">
          {REWARDS.map((r, i) => (
            <div
              key={i}
              className="p-1.5 rounded-xl bg-neutral-800/80 border border-neutral-700/60 flex flex-col items-center"
            >
              <div className="w-2.5 h-2.5 rounded-full mb-1" style={{ backgroundColor: r.color }} />
              <div className="font-mono font-bold text-xs text-white">+{r.coins}</div>
              <div className="text-[9px] text-neutral-400">Coins</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
