import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import {
  Shield,
  ArrowRight,
  Video,
  Disc,
  MessageCircle,
  Coins,
  User,
  Sparkles
} from 'lucide-react';

export const AuthScreen: React.FC = () => {
  const { loginWithGoogle, loginAsGuest } = useApp();
  const [usernameOrEmail, setUsernameOrEmail] = useState(() => {
    if (typeof window !== 'undefined') {
      try {
        const params = new URLSearchParams(window.location.search);
        return params.get('user') || params.get('id') || '';
      } catch {}
    }
    return '';
  });
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleGoogleLogin = async () => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      await loginWithGoogle();
    } catch (err: unknown) {
      console.warn('[Google Auth Error]', err);
      const msg = err instanceof Error ? err.message : String(err);
      if (msg.includes('popup-closed-by-user')) {
        setErrorMessage('Sign-in popup was closed. You can click to retry or continue as Guest.');
      } else if (msg.includes('popup-blocked')) {
        setErrorMessage('Browser blocked popup window. Please enable popups or continue as Guest.');
      } else {
        setErrorMessage('Google Sign-In note: ' + (msg.length < 80 ? msg : 'Unable to complete popup. You can continue as Guest.'));
      }
    } finally {
      setIsLoading(false);
    }
  };

  const handleGuestClick = () => {
    setIsLoading(true);
    setErrorMessage(null);
    try {
      loginAsGuest(usernameOrEmail.trim() || 'Guest User');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-neutral-950 via-neutral-900 to-black text-white flex flex-col items-center justify-center p-4 select-none relative overflow-hidden">
      {/* Background ambient glow circles */}
      <div className="absolute w-96 h-96 bg-rose-600/15 rounded-full blur-3xl pointer-events-none -top-20 -left-20" />
      <div className="absolute w-96 h-96 bg-amber-500/10 rounded-full blur-3xl pointer-events-none -bottom-20 -right-20" />

      <div className="w-full max-w-md bg-neutral-900/90 border border-neutral-800 rounded-3xl p-6 sm:p-8 shadow-2xl backdrop-blur-xl relative z-10 text-center">
        {/* App Logo */}
        <div className="w-16 h-16 rounded-3xl bg-gradient-to-tr from-amber-400 via-rose-500 to-pink-600 flex items-center justify-center mx-auto mb-4 shadow-xl shadow-rose-500/25 ring-4 ring-white/5">
          <Video className="w-8 h-8 text-white stroke-[2.2]" />
        </div>

        <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white mb-1.5">
          Quick<span className="text-rose-500">Chat</span>
        </h1>
        <p className="text-xs sm:text-sm text-neutral-400 max-w-xs mx-auto mb-6">
          Connect with people globally through live video & instant direct chat!
        </p>

        {/* Feature Pill Highlights */}
        <div className="grid grid-cols-3 gap-2 mb-6 text-left">
          <div className="p-2.5 rounded-2xl bg-neutral-800/80 border border-neutral-700/60">
            <div className="w-6 h-6 rounded-lg bg-rose-500/20 text-rose-400 flex items-center justify-center mb-1.5">
              <Video className="w-3.5 h-3.5" />
            </div>
            <div className="text-[11px] font-bold text-white leading-tight">Live Video</div>
            <div className="text-[10px] text-neutral-400">Instant Match</div>
          </div>

          <div className="p-2.5 rounded-2xl bg-neutral-800/80 border border-neutral-700/60">
            <div className="w-6 h-6 rounded-lg bg-blue-500/20 text-blue-400 flex items-center justify-center mb-1.5">
              <MessageCircle className="w-3.5 h-3.5" />
            </div>
            <div className="text-[11px] font-bold text-white leading-tight">Direct Chat</div>
            <div className="text-[10px] text-neutral-400">By ID / Name</div>
          </div>

          <div className="p-2.5 rounded-2xl bg-neutral-800/80 border border-neutral-700/60">
            <div className="w-6 h-6 rounded-lg bg-amber-500/20 text-amber-400 flex items-center justify-center mb-1.5">
              <Disc className="w-3.5 h-3.5" />
            </div>
            <div className="text-[11px] font-bold text-white leading-tight">Spin Wheel</div>
            <div className="text-[10px] text-neutral-400">Daily Coins</div>
          </div>
        </div>

        {/* Optional Username/Email Input */}
        <div className="mb-4 text-left">
          <label className="block text-xs font-semibold text-neutral-300 mb-1.5 ml-1">
            Enter Any Username or Email
          </label>
          <div className="relative">
            <User className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              id="input-login-username"
              value={usernameOrEmail}
              onChange={(e) => setUsernameOrEmail(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  e.preventDefault();
                  handleGuestClick();
                }
              }}
              placeholder="e.g. Alex Rivera or user@example.com"
              className="w-full pl-10 pr-4 py-3 bg-neutral-800/90 border border-neutral-700 rounded-2xl text-sm text-white placeholder:text-neutral-500 focus:outline-none focus:border-rose-500 transition-colors"
            />
          </div>
        </div>

        {errorMessage && (
          <div className="mb-3 p-3 rounded-2xl bg-amber-500/15 border border-amber-500/30 text-amber-300 text-xs text-left">
            {errorMessage}
          </div>
        )}

        {/* Real Firebase Google Sign-In */}
        <button
          type="button"
          id="btn-sign-in-google"
          onClick={handleGoogleLogin}
          disabled={isLoading}
          className="w-full py-3.5 px-4 bg-white hover:bg-neutral-100 text-neutral-900 font-bold rounded-2xl shadow-lg flex items-center justify-center gap-3 transition-all transform active:scale-98 cursor-pointer disabled:opacity-75 mb-2.5"
        >
          {/* Official Google G Logo SVG */}
          <svg className="w-5 h-5 shrink-0" viewBox="0 0 24 24">
            <path
              fill="#4285F4"
              d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
            />
            <path
              fill="#34A853"
              d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
            />
            <path
              fill="#FBBC05"
              d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.06H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.94l2.85-2.22.81-.63z"
            />
            <path
              fill="#EA4335"
              d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.06l3.66 2.84c.87-2.6 3.3-4.52 6.16-4.52z"
            />
          </svg>
          <span className="text-sm font-semibold">
            {isLoading ? 'Connecting to Google...' : 'Sign in with Google'}
          </span>
        </button>

        {/* Quick Guest Login Button */}
        <button
          type="button"
          id="btn-guest-login"
          onClick={handleGuestClick}
          disabled={isLoading}
          className="w-full py-3 px-4 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 hover:text-white font-semibold rounded-2xl border border-neutral-700/80 flex items-center justify-center gap-2 transition-all cursor-pointer text-sm"
        >
          <Sparkles className="w-4 h-4 text-amber-400" />
          <span>Continue as Guest</span>
          <ArrowRight className="w-4 h-4 text-neutral-400 ml-auto" />
        </button>

        {/* Welcome bonus badge */}
        <div className="mt-4 inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs">
          <Coins className="w-3.5 h-3.5" />
          <span>Free Welcome Coins + 5 Daily Spins included</span>
        </div>

        {/* Safe moderation footer */}
        <div className="mt-5 flex items-center justify-center gap-1.5 text-[11px] text-neutral-500">
          <Shield className="w-3.5 h-3.5 text-emerald-500" />
          <span>No external API keys required • Instant safe connection</span>
        </div>
      </div>
    </div>
  );
};
