import React, { createContext, useContext, useState, useEffect, useCallback, useRef, ReactNode } from 'react';
import { AppUser, VideoPartner, Conversation, GenderFilter, NavigationTab, ChatMessage, FemalePass } from '../types';
import { signInWithPopup, signOut, onAuthStateChanged, GoogleAuthProvider } from 'firebase/auth';
import { doc, getDoc, setDoc, collection, query, orderBy, limit, getDocs } from 'firebase/firestore';
import { getFirebaseAuth, getFirebaseDb, createGoogleAuthProvider } from '../services/firebaseConfig';
import {
  syncUserProfileToFirestore,
  addToWaitingQueue,
  removeFromWaitingQueue,
  pairWaitingUsers,
  listenToMatchmakingStatus,
  leaveCallRoom,
  findRealUserById,
  findRandomRealWaitingPeer,
  registerKnownUser,
  sendRealtimeMessage,
  listenToRealtimeMessages,
  listenToChatRoomDoc,
  getChatRoomDocId,
  isSameOrNormalizedUser,
  type CallRoomDocument,
  type PeerProfile,
  type RealtimeChatMessage
} from '../services/firebaseMatchmaking';

/**
 * Standardize User IDs so inputs like "#USER8555", "USER8555", "user8555", "8555"
 * resolve uniformly to "#USER8555".
 */
export function normalizeUserId(input: string): string {
  let cleaned = input.trim();
  if (!cleaned) return '';
  if (cleaned.startsWith('@')) cleaned = cleaned.slice(1).trim();
  cleaned = cleaned.toUpperCase();
  // Digits only e.g. "8555" -> "#USER8555"
  if (/^\d{3,6}$/.test(cleaned)) {
    return `#USER${cleaned}`;
  }
  // "#8555" -> "#USER8555"
  if (/^#\d{3,6}$/.test(cleaned)) {
    return `#USER${cleaned.slice(1)}`;
  }
  // "USER8555" -> "#USER8555"
  if (cleaned.startsWith('USER')) {
    return `#${cleaned}`;
  }
  // If doesn't start with '#' -> prefix '#'
  if (!cleaned.startsWith('#')) {
    return `#${cleaned.replace(/\s+/g, '')}`;
  }
  return cleaned.replace(/\s+/g, '');
}

/**
 * Parses user input for search by either User ID (e.g., #USER8555, 8555) or
 * Username (e.g. Priya, Alex, Rahul, Jordan)
 */
export function parseUserSearchQuery(input: string): {
  normalizedId: string;
  displayName: string;
  isNumericId: boolean;
} {
  let raw = input.trim();
  if (!raw) return { normalizedId: '', displayName: '', isNumericId: false };
  if (raw.startsWith('@')) raw = raw.slice(1).trim();

  // 1. Pure numbers e.g. "8555" -> #USER8555, "User #8555"
  if (/^\d{3,6}$/.test(raw)) {
    return {
      normalizedId: `#USER${raw}`,
      displayName: `User #${raw}`,
      isNumericId: true
    };
  }

  // 2. #8555 -> #USER8555, "User #8555"
  if (/^#\d{3,6}$/.test(raw)) {
    const num = raw.slice(1);
    return {
      normalizedId: `#USER${num}`,
      displayName: `User #${num}`,
      isNumericId: true
    };
  }

  // 3. USER8555 or #USER8555
  if (/^#?USER\d{3,6}$/i.test(raw)) {
    const num = raw.replace(/\D/g, '');
    return {
      normalizedId: `#USER${num}`,
      displayName: `User #${num}`,
      isNumericId: true
    };
  }

  // 4. If starts with # (e.g. #PRIYA or #ALEX)
  if (raw.startsWith('#')) {
    const namePart = raw.slice(1).trim();
    const formattedName = namePart
      ? namePart.charAt(0).toUpperCase() + namePart.slice(1).toLowerCase()
      : 'Friend';
    return {
      normalizedId: raw.toUpperCase().replace(/\s+/g, ''),
      displayName: formattedName,
      isNumericId: false
    };
  }

  // 5. Plain Username (e.g. "priya", "Rahul", "Alex Rivera", "Emily")
  const words = raw.split(/\s+/).filter(Boolean);
  const formattedName = words
    .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
    .join(' ');
  const normalizedId = `#${raw.toUpperCase().replace(/[^a-zA-Z0-9]/g, '')}`;

  return {
    normalizedId,
    displayName: formattedName || 'Friend',
    isNumericId: false
  };
}

const USER_STORAGE_KEY = 'quickchat_user_data_v5';
const CONVERSATIONS_STORAGE_KEY = 'quickchat_convs_data_v5';
const BLOCKED_USERS_STORAGE_KEY = 'quickchat_blocked_users_v2';
const SPIN_COUNT_KEY = 'quickchat_spin_count_v3';
const LAST_SPIN_DATE_KEY = 'quickchat_last_spin_date_v3';
const TEST_RESET_KEY = 'quickchat_test_reset_strict_v3';
const WALLET_RESET_KEY = 'quickchat_wallet_reset_immediate_v2';

const getConversationsStorageKey = (userId?: string | null) => {
  const clean = (userId || '').trim().toUpperCase().replace(/[^A-Z0-9]/g, '');
  return `quickchat_convs_${clean || 'default'}_v5`;
};

const getTodayString = () => new Date().toISOString().slice(0, 10);

const getInitialSpinCount = (): number => {
  try {
    const today = getTodayString();
    const testResetDone = localStorage.getItem(TEST_RESET_KEY);
    if (!testResetDone) {
      // Temporary Test Reset: Reset spin counter right now so user gets 5 fresh spins immediately
      localStorage.setItem(LAST_SPIN_DATE_KEY, today);
      localStorage.setItem(SPIN_COUNT_KEY, '0');
      return 0;
    }

    const storedDate = localStorage.getItem(LAST_SPIN_DATE_KEY);
    const storedCount = localStorage.getItem(SPIN_COUNT_KEY);

    if (storedDate === today && storedCount !== null) {
      const parsed = parseInt(storedCount, 10);
      return isNaN(parsed) ? 0 : Math.min(5, Math.max(0, parsed));
    }
    // New day: reset spinCount to 0 and set today
    localStorage.setItem(LAST_SPIN_DATE_KEY, today);
    localStorage.setItem(SPIN_COUNT_KEY, '0');
    return 0;
  } catch {
    return 0;
  }
};

interface AppContextType {
  // Auth state
  isAuthenticated: boolean;
  currentUser: AppUser | null;
  loginWithGoogle: (nameOrEmail?: string) => Promise<void>;
  loginAsGuest: (nameOrEmail?: string) => void;
  logout: () => void;

  // Navigation
  activeTab: NavigationTab;
  setActiveTab: (tab: NavigationTab) => void;

  // Coins management
  addCoins: (amount: number) => void;
  deductCoins: (amount: number) => boolean;

  // Daily spin
  spinCount: number;
  spinsRemaining: number;
  spinWheel: () => { prize: number; index: number } | null;
  prepareSpin: () => { prize: number; index: number } | null;
  commitSpinReward: (exactPrize: number) => void;
  canSpin: boolean;

  // Female Pass (Dual-Expiry: 15 Calls OR 3 Days)
  femalePass: FemalePass | null;
  isFemalePassActive: boolean;
  femalePassRemainingDays: number;
  unlockFemalePass: () => boolean;
  femalePassCost: number;
  resetSpinCounterForTesting: () => void;

  // Video call state & filter
  genderFilter: GenderFilter;
  setGenderFilter: (filter: GenderFilter) => void;
  currentVideoPartner: VideoPartner | null;
  isCallConnecting: boolean;
  isCallActive: boolean;
  currentCallRoom: CallRoomDocument | null;
  agoraChannel: string | null;
  startVideoMatch: () => void;
  skipToNextPartner: () => void;
  endVideoCall: () => void;
  insufficientCoinsModal: boolean;
  setInsufficientCoinsModal: (show: boolean) => void;

  // Chat conversations
  conversations: Conversation[];
  activeConversation: Conversation | null;
  setActiveConversation: (conv: Conversation | null) => void;
  deleteConversation: (convId: string) => void;
  blockUser: (partnerUserId: string, partnerName?: string) => void;
  reportUser: (partnerUserId: string, reason: string, partnerName?: string) => void;
  blockedUserIds: string[];
  isUserBlocked: (userId: string) => boolean;
  isPartnerTyping: boolean;
  sendMessage: (
    convId: string,
    text: string,
    media?: { type: 'image' | 'video'; url: string; name?: string }
  ) => void;
  startConversationWithUser: (targetUserIdOrPartner: string | VideoPartner) => Promise<{ success: boolean; message: string; conv?: Conversation }>;
  searchPartnerByUserId: (userId: string) => Promise<VideoPartner | null>;
  startRandomTextChat: () => Promise<{ success: boolean; message: string; conv?: Conversation }>;
  updateUniqueUserId: (newId: string) => void;
  updateProfileName: (newName: string) => Promise<boolean>;
  updateProfileAvatar: (newAvatarUrl: string) => void;
  removeProfileAvatar: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // 1. User & Auth state: Must default to null on initial app start so user is forced to the Auth/Login screen
  // unless explicitly logged in with Google Auth or by clicking 'Continue as Guest'.
  // Do not automatically log users in as Guest or bypass the auth screen on initial load.
  const [currentUser, setCurrentUser] = useState<AppUser | null>(null);

  // Clean up any legacy user data keys from older iterations
  useEffect(() => {
    try {
      localStorage.removeItem('liveroulette_user_data_v4');
    } catch {}
  }, []);

  // Rule 1: Immediate Wallet Reset enforcement - ensure balance = 0 immediately on any render/load
  useEffect(() => {
    const hasResetKey = WALLET_RESET_KEY;
    const alreadyReset = localStorage.getItem(hasResetKey);
    if (!alreadyReset && currentUser && currentUser.coins !== 0) {
      const resetUser = { ...currentUser, coins: 0 };
      setCurrentUser(resetUser);
      localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(resetUser));
      localStorage.setItem(hasResetKey, 'true');
    }
  }, [currentUser]);

  const isAuthenticated = !!currentUser;

  // 2. Active Tab
  const [activeTab, setActiveTab] = useState<NavigationTab>('video');

  // 3. Daily Spin state: persisted in localStorage with key 'liveroulette_spin_count_v1' and 'liveroulette_last_spin_date_v1'
  const [spinCount, setSpinCount] = useState<number>(() => getInitialSpinCount());

  // Check and sync spinCount on load and whenever calendar day changes
  useEffect(() => {
    const checkAndSyncDay = () => {
      const today = getTodayString();
      const storedDate = localStorage.getItem(LAST_SPIN_DATE_KEY);
      if (storedDate !== today) {
        // New calendar day: reset spinCount to 0
        localStorage.setItem(LAST_SPIN_DATE_KEY, today);
        localStorage.setItem(SPIN_COUNT_KEY, '0');
        setSpinCount(0);
      }
    };

    checkAndSyncDay();
    // Also check periodically or on window focus so tabs/devices stay consistent
    window.addEventListener('focus', checkAndSyncDay);
    return () => window.removeEventListener('focus', checkAndSyncDay);
  }, []);

  const spinsRemaining = Math.max(0, 5 - spinCount);
  const canSpin = spinCount < 5;

  // 4. Video call state
  const [genderFilter, setGenderFilter] = useState<GenderFilter>('both');
  const [currentVideoPartner, setCurrentVideoPartner] = useState<VideoPartner | null>(null);
  const [isCallConnecting, setIsCallConnecting] = useState<boolean>(false);
  const [isCallActive, setIsCallActive] = useState<boolean>(false);
  const [currentCallRoom, setCurrentCallRoom] = useState<CallRoomDocument | null>(null);
  const [agoraChannel, setAgoraChannel] = useState<string | null>(null);
  const [insufficientCoinsModal, setInsufficientCoinsModal] = useState<boolean>(false);
  const matchmakingCleanupRef = useRef<(() => void) | null>(null);
  const activeChatRoomUnsubRef = useRef<(() => void) | null>(null);

  // 5. Conversations state (scoped per user so multiple tabs don't conflict)
  const [conversations, setConversations] = useState<Conversation[]>(() => {
    try {
      const userKey = getConversationsStorageKey(currentUser?.uniqueUserId);
      const userScoped = localStorage.getItem(userKey);
      if (userScoped) return JSON.parse(userScoped);

      const saved = localStorage.getItem(CONVERSATIONS_STORAGE_KEY);
      if (saved) return JSON.parse(saved);

      const legacy = localStorage.getItem('liveroulette_convs_data_v4');
      if (legacy) return JSON.parse(legacy);
    } catch {
      // fallback
    }
    return [];
  });

  // Re-load conversations if currentUser changes
  useEffect(() => {
    if (!currentUser?.uniqueUserId) return;
    try {
      const userKey = getConversationsStorageKey(currentUser.uniqueUserId);
      const userScoped = localStorage.getItem(userKey);
      if (userScoped) {
        setConversations(JSON.parse(userScoped));
      }
    } catch {}
  }, [currentUser?.uniqueUserId]);

  const [activeConversation, setActiveConversation] = useState<Conversation | null>(null);
  const [isPartnerTyping, setIsPartnerTyping] = useState<boolean>(false);

  // Blocked users state
  const [blockedUserIds, setBlockedUserIds] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem(BLOCKED_USERS_STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Save blocked users to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(BLOCKED_USERS_STORAGE_KEY, JSON.stringify(blockedUserIds));
    } catch {
      // ignore
    }
  }, [blockedUserIds]);

  // Save conversations to both user-scoped and global storage
  useEffect(() => {
    try {
      const userKey = getConversationsStorageKey(currentUser?.uniqueUserId);
      localStorage.setItem(userKey, JSON.stringify(conversations));
      localStorage.setItem(CONVERSATIONS_STORAGE_KEY, JSON.stringify(conversations));
    } catch {
      // ignore
    }
  }, [conversations, currentUser?.uniqueUserId]);

  // Register current user in cross-tab & session known users registry
  useEffect(() => {
    if (currentUser) {
      registerKnownUser({
        userId: currentUser.uniqueUserId,
        name: currentUser.name,
        gender: currentUser.gender,
        avatar: currentUser.avatar,
        city: 'Online',
        country: 'Global',
        countryFlag: '🌐'
      });
    }
  }, [currentUser]);

  // Keep a ref to currentUser and activeConversation so real-time listeners always have fresh context
  const currentUserRef = useRef<AppUser | null>(currentUser);
  useEffect(() => {
    currentUserRef.current = currentUser;
  }, [currentUser]);

  const activeConversationRef = useRef<Conversation | null>(activeConversation);
  useEffect(() => {
    activeConversationRef.current = activeConversation;
  }, [activeConversation]);

  // Select active conversation and clear unread badge
  const selectActiveConversation = useCallback((conv: Conversation | null) => {
    if (conv && conv.unreadCount > 0) {
      setConversations((prev) =>
        prev.map((c) => (c.id === conv.id ? { ...c, unreadCount: 0 } : c))
      );
      setActiveConversation({ ...conv, unreadCount: 0 });
    } else {
      setActiveConversation(conv);
    }
  }, []);

  // Handle incoming real-time messages from any channel (Firestore onSnapshot, BroadcastChannel, SSE, Storage)
  const handleIncomingRealtimeMessage = useCallback((incoming: RealtimeChatMessage) => {
    if (!incoming || !incoming.id) return;

    const senderId = incoming.senderId;
    const cleanSender = senderId.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');

    // Determine if this message was sent by current user
    const currentMyId = currentUserRef.current?.uniqueUserId;
    const isMine = isSameOrNormalizedUser(senderId, currentMyId);

    const newMsg: ChatMessage = {
      id: incoming.id,
      senderId: incoming.senderId,
      recipientId: incoming.recipientId,
      text: incoming.text,
      timestamp:
        incoming.timeString ||
        new Date(incoming.timestamp || Date.now()).toLocaleTimeString([], {
          hour: '2-digit',
          minute: '2-digit'
        }),
      senderName: incoming.senderName,
      isMine,
      mediaType: incoming.mediaType,
      mediaUrl: incoming.mediaUrl,
      mediaName: incoming.mediaName
    };

    const summaryText =
      incoming.text ||
      (incoming.mediaType === 'video' ? '📹 Sent a video' : '📷 Sent a photo');

    const currentActive = activeConversationRef.current;
    const targetPartnerId = isMine ? incoming.recipientId : incoming.senderId;
    const cleanTarget = targetPartnerId.trim().toUpperCase().replace(/[^A-Z0-9]/g, '');

    const isViewingThisThread =
      currentActive &&
      currentActive.partnerUserId.toUpperCase().replace(/[^A-Z0-9]/g, '') === cleanTarget;

    setConversations((prev) => {
      const existingIdx = prev.findIndex(
        (c) => c.partnerUserId.toUpperCase().replace(/[^A-Z0-9]/g, '') === cleanTarget
      );

      if (existingIdx >= 0) {
        const existing = prev[existingIdx];
        // Prevent duplicates
        if (existing.messages.some((m) => m.id === incoming.id)) {
          return prev;
        }

        const updatedConv: Conversation = {
          ...existing,
          lastMessage: summaryText,
          lastMessageTime: 'Just now',
          partnerOnline: true,
          unreadCount: isViewingThisThread || isMine ? 0 : (existing.unreadCount || 0) + 1,
          messages: [...existing.messages, newMsg]
        };

        const rest = prev.filter((_, i) => i !== existingIdx);
        return [updatedConv, ...rest];
      } else {
        // Auto-create new conversation for incoming direct message
        const newConv: Conversation = {
          id: `conv-${cleanTarget}-${Date.now()}`,
          partnerId: `user-${cleanTarget}`,
          partnerUserId: targetPartnerId,
          partnerName: incoming.senderName || `User ${targetPartnerId}`,
          partnerAvatar: incoming.senderAvatar || '',
          partnerGender: 'male',
          partnerOnline: true,
          partnerFlag: '🌐',
          lastMessage: summaryText,
          lastMessageTime: 'Just now',
          unreadCount: isViewingThisThread || isMine ? 0 : 1,
          messages: [newMsg]
        };
        return [newConv, ...prev];
      }
    });

    // Update activeConversation immediately if viewing this thread so it displays live without refreshing
    setActiveConversation((prevActive) => {
      if (!prevActive) return null;
      const isMatch =
        prevActive.partnerUserId.toUpperCase().replace(/[^A-Z0-9]/g, '') === cleanTarget;
      if (!isMatch) return prevActive;

      if (prevActive.messages.some((m) => m.id === incoming.id)) {
        return prevActive;
      }

      return {
        ...prevActive,
        lastMessage: summaryText,
        lastMessageTime: 'Just now',
        messages: [...prevActive.messages, newMsg]
      };
    });
  }, []);

  // Handle batch loaded messages ordered by timestamp ascending from Firestore
  const handleBatchMessages = useCallback((incomingList: RealtimeChatMessage[]) => {
    if (!incomingList || incomingList.length === 0) return;
    const currentMyId = currentUserRef.current?.uniqueUserId;
    if (!currentMyId) return;

    const first = incomingList[0];
    const isFirstMine = isSameOrNormalizedUser(first.senderId, currentMyId);
    const partnerId = isFirstMine ? first.recipientId : first.senderId;
    const cleanPartner = partnerId.trim().replace(/^#/, '').toUpperCase().replace(/[^A-Z0-9_-]/g, '');

    const formattedMsgs: ChatMessage[] = incomingList.map((incoming) => {
      const isMine = isSameOrNormalizedUser(incoming.senderId, currentMyId);
      return {
        id: incoming.id,
        senderId: incoming.senderId,
        recipientId: incoming.recipientId,
        text: incoming.text,
        timestamp:
          incoming.timeString ||
          new Date(incoming.timestamp || Date.now()).toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit'
          }),
        senderName: incoming.senderName,
        isMine,
        mediaType: incoming.mediaType,
        mediaUrl: incoming.mediaUrl,
        mediaName: incoming.mediaName
      };
    });

    const lastMsg = formattedMsgs[formattedMsgs.length - 1];
    const summaryText =
      lastMsg.text ||
      (lastMsg.mediaType === 'video' ? '📹 Sent a video' : '📷 Sent a photo');

    setConversations((prev) => {
      const existingIdx = prev.findIndex(
        (c) => c.partnerUserId.replace(/^#/, '').toUpperCase().replace(/[^A-Z0-9_-]/g, '') === cleanPartner
      );

      if (existingIdx >= 0) {
        const existing = prev[existingIdx];
        const msgMap = new Map<string, ChatMessage>();
        existing.messages.forEach((m) => msgMap.set(m.id, m));
        formattedMsgs.forEach((m) => msgMap.set(m.id, m));
        const mergedMessages = Array.from(msgMap.values());

        const updatedConv: Conversation = {
          ...existing,
          lastMessage: summaryText,
          lastMessageTime: 'Just now',
          messages: mergedMessages
        };

        const rest = prev.filter((_, i) => i !== existingIdx);
        return [updatedConv, ...rest];
      }
      return prev;
    });

    setActiveConversation((prevActive) => {
      if (!prevActive) return null;
      const isActiveMatch =
        prevActive.partnerUserId.replace(/^#/, '').toUpperCase().replace(/[^A-Z0-9_-]/g, '') === cleanPartner;
      if (!isActiveMatch) return prevActive;

      const msgMap = new Map<string, ChatMessage>();
      prevActive.messages.forEach((m) => msgMap.set(m.id, m));
      formattedMsgs.forEach((m) => msgMap.set(m.id, m));
      const mergedMessages = Array.from(msgMap.values());

      return {
        ...prevActive,
        lastMessage: summaryText,
        lastMessageTime: 'Just now',
        messages: mergedMessages
      };
    });
  }, []);

  // Helper to immediately attach the onSnapshot listener to the combined roomId
  const attachChatRoomListener = useCallback(
    (targetPartnerUserId: string) => {
      if (!currentUserRef.current?.uniqueUserId || !targetPartnerUserId) return () => {};
      const currentMyId = currentUserRef.current.uniqueUserId;
      const combinedRoomId = getChatRoomDocId(currentMyId, targetPartnerUserId);

      console.log(`[AppContext] Immediately triggering onSnapshot for combined roomId: chats/${combinedRoomId}/messages`, {
        currentUser: currentMyId,
        targetUser: targetPartnerUserId,
        combinedRoomId
      });

      // Cleanup any previous subscription
      if (activeChatRoomUnsubRef.current) {
        activeChatRoomUnsubRef.current();
        activeChatRoomUnsubRef.current = null;
      }

      const cleanup = listenToChatRoomDoc(
        currentMyId,
        targetPartnerUserId,
        handleIncomingRealtimeMessage,
        handleBatchMessages
      );
      activeChatRoomUnsubRef.current = cleanup;
      return cleanup;
    },
    [handleIncomingRealtimeMessage, handleBatchMessages]
  );

  // 1. Global listener for user inbox & incoming messages across all conversations
  useEffect(() => {
    if (!currentUser?.uniqueUserId) return;
    const cleanup = listenToRealtimeMessages(currentUser.uniqueUserId, handleIncomingRealtimeMessage);
    return () => {
      cleanup();
    };
  }, [currentUser?.uniqueUserId, handleIncomingRealtimeMessage]);

  // 2. Real-time Firestore Chat Room Document listener bound to the combined Room ID
  // (e.g., chats/USER6969_USER8555/messages) shared by both Sender and Receiver.
  // When User A sends a message, an immediate onSnapshot event triggers User B's UI to update live.
  useEffect(() => {
    if (!currentUser?.uniqueUserId || !activeConversation?.partnerUserId) {
      if (activeChatRoomUnsubRef.current) {
        activeChatRoomUnsubRef.current();
        activeChatRoomUnsubRef.current = null;
      }
      return;
    }

    attachChatRoomListener(activeConversation.partnerUserId);

    return () => {
      if (activeChatRoomUnsubRef.current) {
        activeChatRoomUnsubRef.current();
        activeChatRoomUnsubRef.current = null;
      }
    };
  }, [currentUser?.uniqueUserId, activeConversation?.partnerUserId, attachChatRoomListener]);

  // 3. Listen to all background conversations via onSnapshot so real-time updates are received immediately
  useEffect(() => {
    if (!currentUser?.uniqueUserId || !conversations || conversations.length === 0) return;

    const activePartnerClean = activeConversation?.partnerUserId
      ? activeConversation.partnerUserId.trim().replace(/^#/, '').toUpperCase().replace(/[^A-Z0-9_-]/g, '')
      : '';

    const cleanups: Array<() => void> = [];
    conversations.forEach((conv) => {
      const convPartnerClean = conv.partnerUserId.trim().replace(/^#/, '').toUpperCase().replace(/[^A-Z0-9_-]/g, '')
      if (convPartnerClean && convPartnerClean !== activePartnerClean) {
        const cleanup = listenToChatRoomDoc(
          currentUser.uniqueUserId,
          conv.partnerUserId,
          handleIncomingRealtimeMessage
        );
        cleanups.push(cleanup);
      }
    });

    return () => {
      cleanups.forEach((c) => c());
    };
  }, [currentUser?.uniqueUserId, conversations.length, activeConversation?.partnerUserId, handleIncomingRealtimeMessage]);

  // Save user changes to localStorage, sessionStorage, and Firestore
  const saveUser = useCallback((user: AppUser | null) => {
    setCurrentUser(user);
    if (user) {
      localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(user));
      try {
        sessionStorage.setItem('quickchat_tab_user', JSON.stringify(user));
      } catch {}
      registerKnownUser({
        userId: user.uniqueUserId,
        name: user.name,
        gender: user.gender,
        avatar: user.avatar,
        city: 'Online',
        country: 'Global',
        countryFlag: '🌐'
      });
      // Real-time Firestore sync of User Document schema
      syncUserProfileToFirestore({
        userId: user.uniqueUserId,
        name: user.name,
        gender: user.gender,
        avatar: user.avatar,
        coins: user.coins,
        dailySpinsLeft: Math.max(0, 5 - user.spinCount),
        femalePassActive: !!(
          user.femalePass?.isActive &&
          user.femalePass.callsRemaining > 0 &&
          Date.now() < user.femalePass.expiresAt
        ),
        remainingPassCalls: user.femalePass?.callsRemaining ?? 0,
        passExpiryTimestamp: user.femalePass?.expiresAt ?? null
      });
    } else {
      localStorage.removeItem(USER_STORAGE_KEY);
      try {
        sessionStorage.removeItem('quickchat_tab_user');
      } catch {}
    }
  }, []);

  // Update Unique User ID on the fly (e.g. for cross-tab multi-user testing like #USER6969)
  const updateUniqueUserId = useCallback((newId: string) => {
    const clean = newId.trim().toUpperCase();
    if (!clean) return;
    const formatted = clean.startsWith('#') ? clean : `#${clean}`;

    setCurrentUser((prev) => {
      const base: AppUser = prev || {
        id: `usr-${Date.now()}`,
        name: formatted === '#USER6969' ? 'Jordan Blake' : 'Alex Rivera',
        email: `${formatted.replace('#', '').toLowerCase()}@example.com`,
        avatar: '',
        uniqueUserId: formatted,
        gender: formatted === '#USER6969' ? 'female' : 'male',
        coins: 0,
        totalCoinsWon: 0,
        totalCallsMade: 0,
        joinedDate: 'Joined Today',
        spinCount: 0,
        dailySpinsRemaining: 5,
        lastSpinDate: getTodayString(),
        femalePass: {
          isActive: false,
          callsRemaining: 0,
          expiresAt: 0,
          activatedAt: 0
        }
      };

      const updated: AppUser = {
        ...base,
        uniqueUserId: formatted,
        name: formatted === '#USER6969' && base.name === 'Alex Rivera' ? 'Jordan Blake' : base.name,
        avatar: base.avatar.includes('images.unsplash.com') ? '' : base.avatar
      };
      localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(updated));
      try {
        sessionStorage.setItem('quickchat_tab_user', JSON.stringify(updated));
      } catch {}
      registerKnownUser({
        userId: updated.uniqueUserId,
        name: updated.name,
        gender: updated.gender,
        avatar: updated.avatar,
        city: 'Online',
        country: 'Global',
        countryFlag: '🌐'
      });
      syncUserProfileToFirestore({
        userId: updated.uniqueUserId,
        name: updated.name,
        gender: updated.gender,
        avatar: updated.avatar,
        coins: updated.coins,
        dailySpinsLeft: Math.max(0, 5 - updated.spinCount),
        femalePassActive: !!(
          updated.femalePass?.isActive &&
          updated.femalePass.callsRemaining > 0 &&
          Date.now() < updated.femalePass.expiresAt
        ),
        remainingPassCalls: updated.femalePass?.callsRemaining ?? 0,
        passExpiryTimestamp: updated.femalePass?.expiresAt ?? null
      }).catch(() => {});
      return updated;
    });
  }, []);

  // Update Profile Name immediately and sync across local storage, session storage, and Firestore
  const updateProfileName = useCallback(async (newName: string): Promise<boolean> => {
    const trimmed = newName.trim();
    if (!trimmed) return false;

    let updatedUser: AppUser | null = null;
    setCurrentUser((prev) => {
      if (!prev) return null;
      const updated: AppUser = {
        ...prev,
        name: trimmed
      };
      updatedUser = updated;
      localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(updated));
      try {
        sessionStorage.setItem('quickchat_tab_user', JSON.stringify(updated));
      } catch {}
      registerKnownUser({
        userId: updated.uniqueUserId,
        name: updated.name,
        gender: updated.gender,
        avatar: updated.avatar,
        city: 'Online',
        country: 'Global',
        countryFlag: '🌐'
      });
      return updated;
    });

    if (updatedUser) {
      const u = updatedUser as AppUser;
      // 1. Sync to public profile entry in Firestore
      syncUserProfileToFirestore({
        userId: u.uniqueUserId,
        name: u.name,
        gender: u.gender,
        avatar: u.avatar,
        coins: u.coins,
        dailySpinsLeft: Math.max(0, 5 - (u.spinCount || 0)),
        femalePassActive: !!(
          u.femalePass?.isActive &&
          u.femalePass.callsRemaining > 0 &&
          Date.now() < u.femalePass.expiresAt
        ),
        remainingPassCalls: u.femalePass?.callsRemaining ?? 0,
        passExpiryTimestamp: u.femalePass?.expiresAt ?? null
      }).catch(() => {});

      // 2. Also sync to user document in Firestore by auth UID and normalized ID
      const db = getFirebaseDb();
      if (db) {
        try {
          if (u.id) {
            await setDoc(
              doc(db, 'users', u.id),
              { name: u.name, updatedAt: Date.now() },
              { merge: true }
            );
          }
          const cleanDocId = u.uniqueUserId.replace(/[^a-zA-Z0-9]/g, '');
          if (cleanDocId && cleanDocId !== u.id) {
            await setDoc(
              doc(db, 'users', cleanDocId),
              { name: u.name, updatedAt: Date.now() },
              { merge: true }
            );
          }
        } catch (err) {
          console.warn('[Firebase] Profile name doc sync note:', err);
        }
      }
    }

    return true;
  }, []);

  // Update Profile Picture (DP) immediately and sync across storage and Firestore
  const updateProfileAvatar = useCallback((newAvatarUrl: string) => {
    setCurrentUser((prev) => {
      if (!prev) return null;
      const updated: AppUser = {
        ...prev,
        avatar: newAvatarUrl || ''
      };
      localStorage.setItem(USER_STORAGE_KEY, JSON.stringify(updated));
      try {
        sessionStorage.setItem('quickchat_tab_user', JSON.stringify(updated));
      } catch {}
      registerKnownUser({
        userId: updated.uniqueUserId,
        name: updated.name,
        gender: updated.gender,
        avatar: updated.avatar,
        city: 'Online',
        country: 'Global',
        countryFlag: '🌐'
      });
      syncUserProfileToFirestore({
        userId: updated.uniqueUserId,
        name: updated.name,
        gender: updated.gender,
        avatar: updated.avatar,
        coins: updated.coins,
        dailySpinsLeft: Math.max(0, 5 - (updated.spinCount || 0)),
        femalePassActive: !!(
          updated.femalePass?.isActive &&
          updated.femalePass.callsRemaining > 0 &&
          Date.now() < updated.femalePass.expiresAt
        ),
        remainingPassCalls: updated.femalePass?.callsRemaining ?? 0,
        passExpiryTimestamp: updated.femalePass?.expiresAt ?? null
      }).catch(() => {});
      return updated;
    });
  }, []);

  const removeProfileAvatar = useCallback(() => {
    updateProfileAvatar('');
  }, [updateProfileAvatar]);

  // Ensure default DP is blank instead of random mock stock photos from Unsplash
  useEffect(() => {
    if (currentUser?.avatar && currentUser.avatar.includes('images.unsplash.com')) {
      updateProfileAvatar('');
    }
  }, [currentUser?.avatar, updateProfileAvatar]);

  // Listen for real Firebase Google Auth state changes & sync user profile
  useEffect(() => {
    const auth = getFirebaseAuth();
    if (!auth) return;

    const unsubscribe = onAuthStateChanged(auth, async (fbUser) => {
      if (fbUser) {
        const db = getFirebaseDb();
        let uniqueId = `#USER${fbUser.uid.slice(-4).toUpperCase()}`;
        let coins = 0;
        let savedName = fbUser.displayName || 'Google User';
        let femalePass: FemalePass = {
          isActive: false,
          callsRemaining: 0,
          expiresAt: 0,
          activatedAt: 0
        };

        if (db) {
          try {
            const userSnap = await getDoc(doc(db, 'users', fbUser.uid));
            if (userSnap.exists()) {
              const data = userSnap.data();
              if (data.uniqueUserId) uniqueId = data.uniqueUserId;
              if (data.name) savedName = data.name;
              if (typeof data.coins === 'number') coins = data.coins;
              if (data.femalePass) femalePass = data.femalePass;
            }
          } catch (err) {
            console.warn('[Firebase Auth] User doc fetch note:', err);
          }
        }

        const realUser: AppUser = {
          id: fbUser.uid,
          name: savedName,
          email: fbUser.email || '',
          avatar: fbUser.photoURL || '',
          uniqueUserId: uniqueId,
          gender: 'male',
          coins: coins,
          totalCoinsWon: 0,
          totalCallsMade: 0,
          joinedDate: 'Joined Today',
          spinCount: spinCount,
          dailySpinsRemaining: spinsRemaining,
          lastSpinDate: getTodayString(),
          femalePass
        };

        saveUser(realUser);
        registerKnownUser({
          userId: realUser.uniqueUserId,
          name: realUser.name,
          gender: realUser.gender,
          avatar: realUser.avatar,
          city: 'Online',
          country: 'Global',
          countryFlag: '🌐'
        });

        if (db) {
          try {
            await setDoc(
              doc(db, 'users', fbUser.uid),
              {
                userId: fbUser.uid,
                uniqueUserId: uniqueId,
                name: realUser.name,
                email: realUser.email,
                avatar: realUser.avatar,
                gender: realUser.gender,
                coins: realUser.coins,
                dailySpinsLeft: realUser.dailySpinsRemaining,
                updatedAt: Date.now()
              },
              { merge: true }
            );
          } catch (e) {
            console.warn('[Firebase] setDoc user note:', e);
          }
        }
      }
    });

    return () => unsubscribe();
  }, [saveUser, spinCount, spinsRemaining]);

  // Guest / Demo user creator
  const createOrLoginUser = useCallback((nameOrEmail?: string): AppUser => {
    const raw = (nameOrEmail || '').trim();
    const isEmail = raw.includes('@');
    let displayName = 'Alex Rivera';
    let email = 'alex.rivera@example.com';

    if (raw) {
      if (isEmail) {
        email = raw;
        const prefix = raw.split('@')[0];
        displayName = prefix
          ? prefix.charAt(0).toUpperCase() + prefix.slice(1)
          : 'Guest User';
      } else {
        displayName = raw
          .split(' ')
          .map((p) => p.charAt(0).toUpperCase() + p.slice(1))
          .join(' ');
        email = `${raw.toLowerCase().replace(/[^a-z0-9]/g, '')}@example.com`;
      }
    }

    const randomSuffix = Math.floor(1000 + Math.random() * 9000);
    const userId = raw.startsWith('#')
      ? raw.toUpperCase()
      : `#USER${randomSuffix}`;

    const user: AppUser = {
      id: `usr-${Date.now()}-${randomSuffix}`,
      name: displayName,
      email: email,
      avatar: '',
      uniqueUserId: userId,
      gender: 'male',
      coins: 0,
      totalCoinsWon: 0,
      totalCallsMade: 0,
      joinedDate: 'Joined Today',
      spinCount: spinCount,
      dailySpinsRemaining: spinsRemaining,
      lastSpinDate: getTodayString(),
      femalePass: {
        isActive: false,
        callsRemaining: 0,
        expiresAt: 0,
        activatedAt: 0
      }
    };

    saveUser(user);
    // Register into known users registry and sync with Firestore
    registerKnownUser({
      userId: user.uniqueUserId,
      name: user.name,
      gender: user.gender,
      avatar: user.avatar,
      city: 'Online',
      country: 'Global',
      countryFlag: '🌐',
      age: 23
    });

    const db = getFirebaseDb();
    if (db) {
      setDoc(
        doc(db, 'users', user.uniqueUserId.replace('#', '')),
        {
          userId: user.uniqueUserId,
          uniqueUserId: user.uniqueUserId,
          name: user.name,
          email: user.email,
          avatar: user.avatar,
          gender: user.gender,
          coins: user.coins,
          dailySpinsLeft: user.dailySpinsRemaining,
          updatedAt: Date.now()
        },
        { merge: true }
      ).catch(() => {});
    }

    setActiveTab('video');
    return user;
  }, [saveUser, spinCount, spinsRemaining]);

  // Real Firebase Google Auth
  const loginWithGoogle = async (): Promise<void> => {
    const auth = getFirebaseAuth();
    if (!auth) {
      throw new Error('Firebase Authentication is not initialized.');
    }
    const provider = createGoogleAuthProvider();
    const result = await signInWithPopup(auth, provider);
    const fbUser = result.user;

    const db = getFirebaseDb();
    let uniqueId = `#USER${fbUser.uid.slice(-4).toUpperCase()}`;
    let coins = 0;
    let savedName = fbUser.displayName || 'Google User';
    let femalePass: FemalePass = {
      isActive: false,
      callsRemaining: 0,
      expiresAt: 0,
      activatedAt: 0
    };

    if (db) {
      try {
        const userSnap = await getDoc(doc(db, 'users', fbUser.uid));
        if (userSnap.exists()) {
          const data = userSnap.data();
          if (data.uniqueUserId) uniqueId = data.uniqueUserId;
          if (data.name) savedName = data.name;
          if (typeof data.coins === 'number') coins = data.coins;
          if (data.femalePass) femalePass = data.femalePass;
        }
      } catch (err) {
        console.warn('[Firebase] Error reading user doc:', err);
      }
    }

    const appUser: AppUser = {
      id: fbUser.uid,
      name: savedName,
      email: fbUser.email || '',
      avatar: fbUser.photoURL || '',
      uniqueUserId: uniqueId,
      gender: 'male',
      coins: coins,
      totalCoinsWon: 0,
      totalCallsMade: 0,
      joinedDate: 'Joined Today',
      spinCount: spinCount,
      dailySpinsRemaining: spinsRemaining,
      lastSpinDate: getTodayString(),
      femalePass
    };

    saveUser(appUser);
    registerKnownUser({
      userId: appUser.uniqueUserId,
      name: appUser.name,
      gender: appUser.gender,
      avatar: appUser.avatar,
      city: 'Online',
      country: 'Global',
      countryFlag: '🌐'
    });

    if (db) {
      try {
        await setDoc(
          doc(db, 'users', fbUser.uid),
          {
            userId: fbUser.uid,
            uniqueUserId: uniqueId,
            name: appUser.name,
            email: appUser.email,
            avatar: appUser.avatar,
            gender: appUser.gender,
            coins: appUser.coins,
            dailySpinsLeft: appUser.dailySpinsRemaining,
            updatedAt: Date.now()
          },
          { merge: true }
        );
      } catch (e) {
        console.warn('[Firebase] setDoc user note:', e);
      }
    }

    setActiveTab('video');
  };

  // Simple Guest Login
  const loginAsGuest = useCallback((nameOrEmail?: string) => {
    createOrLoginUser(nameOrEmail || 'Guest User');
  }, [createOrLoginUser]);

  const logout = () => {
    try {
      const auth = getFirebaseAuth();
      if (auth) {
        signOut(auth).catch(() => {});
      }
    } catch {}
    saveUser(null);
    setCurrentVideoPartner(null);
    setIsCallActive(false);
  };

  // Add coins
  const addCoins = useCallback((amount: number) => {
    if (!currentUser) return;
    const updated: AppUser = {
      ...currentUser,
      coins: currentUser.coins + amount,
      totalCoinsWon: currentUser.totalCoinsWon + amount
    };
    saveUser(updated);
  }, [currentUser, saveUser]);

  // Deduct coins
  const deductCoins = useCallback((amount: number): boolean => {
    if (!currentUser) return false;
    if (currentUser.coins < amount) return false;
    const updated: AppUser = {
      ...currentUser,
      coins: currentUser.coins - amount
    };
    saveUser(updated);
    return true;
  }, [currentUser, saveUser]);

  // Spin Wheel action: Exact rewards mapping strictly [50, 100, 200, 400, 500]
  const PRIZES = [50, 100, 200, 400, 500] as const;

  // 1. Roll the prize index and decrement daily spin count immediately (Strict limit: Max 5 per day)
  const prepareSpin = useCallback((): { prize: number; index: number } | null => {
    // STRICT GUARD CLAUSE: Prevent any bypass if 5 spins already reached
    if (spinCount >= 5) return null;
    if (!currentUser) return null;

    const newSpinCount = spinCount + 1;
    const today = getTodayString();

    // Persist spinCount and lastSpinDate in localStorage so reloads never reset
    try {
      localStorage.setItem(SPIN_COUNT_KEY, newSpinCount.toString());
      localStorage.setItem(LAST_SPIN_DATE_KEY, today);
    } catch {
      // ignore
    }

    setSpinCount(newSpinCount);

    const prizeIndex = Math.floor(Math.random() * PRIZES.length);
    const wonCoins = PRIZES[prizeIndex];

    const updated: AppUser = {
      ...currentUser,
      spinCount: newSpinCount,
      dailySpinsRemaining: Math.max(0, 5 - newSpinCount),
      lastSpinTimestamp: Date.now(),
      lastSpinDate: today
    };
    saveUser(updated);

    return { prize: wonCoins, index: prizeIndex };
  }, [spinCount, currentUser, saveUser]);

  // 2. Commit exact coins: Updated Balance = Current Balance + Exact Spin Reward Value
  const commitSpinReward = useCallback((exactPrize: number) => {
    if (!currentUser) return;
    const updated: AppUser = {
      ...currentUser,
      coins: currentUser.coins + exactPrize,
      totalCoinsWon: currentUser.totalCoinsWon + exactPrize
    };
    saveUser(updated);
  }, [currentUser, saveUser]);

  // Legacy/direct fallback method for spinWheel
  const spinWheel = useCallback((): { prize: number; index: number } | null => {
    const res = prepareSpin();
    if (res) {
      commitSpinReward(res.prize);
    }
    return res;
  }, [prepareSpin, commitSpinReward]);

  // Video matching logic & Female Pass (Dual-Expiry: 15 Calls OR 3 Days)
  const FEMALE_PASS_COST = 10000;
  const FEMALE_PASS_MAX_CALLS = 15;
  const FEMALE_PASS_DURATION_MS = 3 * 24 * 60 * 60 * 1000; // 3 Days (72 hours)

  const femalePass = currentUser?.femalePass ?? null;

  // Check if female pass is active: <= 15 calls AND <= 3 days elapsed
  const isFemalePassActive = Boolean(
    femalePass &&
    femalePass.isActive &&
    femalePass.callsRemaining > 0 &&
    Date.now() < femalePass.expiresAt
  );

  // Calculate remaining days for live status badge
  const femalePassRemainingDays = femalePass
    ? Math.max(1, Math.ceil(Math.max(0, femalePass.expiresAt - Date.now()) / (1000 * 60 * 60 * 24)))
    : 0;

  // Unlock Female Pass for 10,000 coins (activates 15 calls OR 3 days)
  const unlockFemalePass = useCallback((): boolean => {
    if (!currentUser) return false;
    if (currentUser.coins < FEMALE_PASS_COST) {
      setInsufficientCoinsModal(true);
      return false;
    }

    const updatedUser: AppUser = {
      ...currentUser,
      coins: 0, // Wallet drops to 0 coins upon purchasing the Female Pass
      femalePass: {
        isActive: true,
        callsRemaining: FEMALE_PASS_MAX_CALLS, // Max 15 calls
        expiresAt: Date.now() + FEMALE_PASS_DURATION_MS, // 3 Days validity (72h)
        activatedAt: Date.now()
      }
    };

    saveUser(updatedUser);
    setInsufficientCoinsModal(false);
    return true;
  }, [currentUser, saveUser]);

  // Temporary Test Reset & Daily Spin Fix helper
  const resetSpinCounterForTesting = useCallback(() => {
    const today = getTodayString();
    try {
      localStorage.setItem(SPIN_COUNT_KEY, '0');
      localStorage.setItem(LAST_SPIN_DATE_KEY, today);
    } catch {
      // ignore
    }
    setSpinCount(0);
    if (currentUser) {
      const updated: AppUser = {
        ...currentUser,
        spinCount: 0,
        dailySpinsRemaining: 5,
        lastSpinDate: today
      };
      saveUser(updated);
    }
  }, [currentUser, saveUser]);

  const startVideoMatch = useCallback(() => {
    if (!currentUser) return;

    // Rule 2: Enforce Female Video Call Gating
    // User MUST NOT be able to make a Female Video Call unless they have an Active Female Pass or 10,000 coins
    if (genderFilter === 'female') {
      const isPassValid =
        currentUser.femalePass &&
        currentUser.femalePass.isActive &&
        currentUser.femalePass.callsRemaining > 0 &&
        Date.now() < currentUser.femalePass.expiresAt;

      if (!isPassValid) {
        // DO NOT connect the call. Open modal immediately
        setIsCallConnecting(false);
        setIsCallActive(false);
        setCurrentVideoPartner(null);
        setInsufficientCoinsModal(true);
        return;
      }
    }

    // Clean up any existing active matchmaking timer/listeners
    if (matchmakingCleanupRef.current) {
      matchmakingCleanupRef.current();
      matchmakingCleanupRef.current = null;
    }

    // Set searching state - will remain active until a REAL peer matches!
    setIsCallConnecting(true);
    setIsCallActive(false);
    setCurrentVideoPartner(null);
    setCurrentCallRoom(null);
    setAgoraChannel(null);

    // 1. Add current user to waiting queue with their profile info
    addToWaitingQueue({
      userId: currentUser.uniqueUserId,
      name: currentUser.name,
      gender: currentUser.gender,
      genderFilter: genderFilter,
      city: 'Online',
      country: 'Global',
      countryFlag: '🌐'
    });

    let isMatchingActive = true;

    // Handler when a real peer is matched
    const handleMatchFound = (room: CallRoomDocument) => {
      if (!isMatchingActive) return;
      isMatchingActive = false;

      // Stop polling and listeners
      if (matchmakingCleanupRef.current) {
        matchmakingCleanupRef.current();
        matchmakingCleanupRef.current = null;
      }

      const otherUserId = room.participants.find((p) => p !== currentUser.uniqueUserId) || 'PEER_USER';
      const partnerInfo = room.partnerInfo || {
        userId: otherUserId,
        name: `User ${otherUserId}`,
        gender: genderFilter === 'male' ? 'male' : genderFilter === 'female' ? 'female' : 'male',
        city: 'Online',
        country: 'Global',
        countryFlag: '🌐'
      };

      const realPartner: VideoPartner = {
        id: `peer-${partnerInfo.userId}`,
        userId: partnerInfo.userId,
        name: partnerInfo.name,
        age: partnerInfo.age || 24,
        gender: partnerInfo.gender,
        country: partnerInfo.country || 'Global',
        countryFlag: partnerInfo.countryFlag || '🌐',
        city: partnerInfo.city || 'Online',
        avatar: partnerInfo.avatar || '',
        bio: 'Matched via real-time P2P Video Match',
        interests: ['Live Video', 'P2P', 'Chat'],
        isOnline: true
      };

      setCurrentCallRoom(room);
      setAgoraChannel(room.agoraChannel);
      setCurrentVideoPartner(realPartner);
      setIsCallConnecting(false);
      setIsCallActive(true);

      // Decrement Female Pass call count by 1 after each connected call
      if (currentUser) {
        let updatedFemalePass = currentUser.femalePass;

        if (genderFilter === 'female' && updatedFemalePass) {
          const newCallsRemaining = Math.max(0, updatedFemalePass.callsRemaining - 1);
          const isTimeExpired = Date.now() >= updatedFemalePass.expiresAt;
          // Dual-Expiry: If user completes 15 calls OR 3 days pass, EXPIRES immediately
          const isStillActive = newCallsRemaining > 0 && !isTimeExpired;

          updatedFemalePass = {
            ...updatedFemalePass,
            callsRemaining: newCallsRemaining,
            isActive: isStillActive
          };
        }

        saveUser({
          ...currentUser,
          totalCallsMade: currentUser.totalCallsMade + 1,
          femalePass: updatedFemalePass
        });
      }
    };

    // 2. Real-time listener for incoming peer match notifications
    const unsub = listenToMatchmakingStatus(currentUser.uniqueUserId, (matchedRoom) => {
      if (isMatchingActive) {
        handleMatchFound(matchedRoom);
      }
    });

    // 3. Active pairing poll: looks for other waiting users in queue
    // If NO online user is available, returns null and continues searching!
    const tryPair = async () => {
      if (!isMatchingActive) return;
      try {
        const matched = await pairWaitingUsers(currentUser.uniqueUserId, genderFilter, {
          userId: currentUser.uniqueUserId,
          name: currentUser.name,
          gender: currentUser.gender,
          city: 'Online',
          country: 'Global',
          countryFlag: '🌐'
        });
        if (matched && isMatchingActive) {
          handleMatchFound(matched);
        }
      } catch (err) {
        console.warn('[P2P Matchmaking] Pair poll check note:', err);
      }
    };

    // Attempt pairing immediately
    tryPair();

    // Poll periodically every 2.5 seconds until a real user joins
    const pollInterval = setInterval(tryPair, 2500);

    matchmakingCleanupRef.current = () => {
      isMatchingActive = false;
      clearInterval(pollInterval);
      unsub();
    };
  }, [currentUser, genderFilter, saveUser]);

  const endVideoCall = useCallback(() => {
    if (matchmakingCleanupRef.current) {
      matchmakingCleanupRef.current();
      matchmakingCleanupRef.current = null;
    }
    if (currentCallRoom && currentUser) {
      leaveCallRoom(currentCallRoom.callRoomId, currentUser.uniqueUserId);
    } else if (currentUser) {
      removeFromWaitingQueue(currentUser.uniqueUserId);
    }
    setCurrentCallRoom(null);
    setAgoraChannel(null);
    setIsCallActive(false);
    setIsCallConnecting(false);
    setCurrentVideoPartner(null);
  }, [currentCallRoom, currentUser]);

  const skipToNextPartner = useCallback(() => {
    endVideoCall();
    setTimeout(() => {
      startVideoMatch();
    }, 150);
  }, [endVideoCall, startVideoMatch]);

  // Search partner by User ID or Username (Instantly connects locally/simulated for live chat)
  const searchPartnerByUserId = useCallback(
    async (targetQuery: string): Promise<VideoPartner | null> => {
      const parsed = parseUserSearchQuery(targetQuery);
      const cleanId = parsed.normalizedId;
      const displayName = parsed.displayName;
      if (!cleanId || cleanId.length < 2) return null;

      // Cannot search for self
      if (
        currentUser &&
        (cleanId === currentUser.uniqueUserId.toUpperCase() ||
          cleanId.replace('#', '') === currentUser.uniqueUserId.replace('#', '').toUpperCase() ||
          displayName.toLowerCase() === currentUser.name.toLowerCase())
      ) {
        return null;
      }

      // 1. First check existing conversations for already known partner by ID or Name
      const inConv = conversations.find(
        (c) =>
          c.partnerUserId.toUpperCase() === cleanId ||
          c.partnerUserId.replace('#', '').toUpperCase() === cleanId.replace('#', '') ||
          c.partnerName.toLowerCase() === displayName.toLowerCase() ||
          c.partnerName.toLowerCase().includes(displayName.toLowerCase())
      );
      if (inConv) {
        return {
          id: inConv.partnerId,
          userId: inConv.partnerUserId,
          name: inConv.partnerName,
          age: 23,
          gender: inConv.partnerGender,
          country: 'Global',
          countryFlag: inConv.partnerFlag || '🌐',
          city: 'Online',
          avatar: inConv.partnerAvatar || '',
          bio: 'Chat partner on QuickChat',
          interests: ['Social', 'Live Chat'],
          isOnline: inConv.partnerOnline ?? true
        };
      }

      // 2. Query real registered user from matchmaking / local registry by ID or Name
      const realPeer = (await findRealUserById(cleanId)) || (await findRealUserById(displayName));
      if (realPeer) {
        return {
          id: `user-${realPeer.userId.replace(/[^a-zA-Z0-9]/g, '')}`,
          userId: realPeer.userId,
          name: realPeer.name,
          age: realPeer.age || 23,
          gender: realPeer.gender || 'male',
          country: realPeer.country || 'Global',
          countryFlag: realPeer.countryFlag || '🌐',
          city: realPeer.city || 'Online',
          avatar: realPeer.avatar || '',
          bio: `Active user on QuickChat`,
          interests: ['Social', 'Live Video'],
          isOnline: true
        };
      }

      // 3. User created locally / simulated for live chat:
      // Instantly generate a clean profile with blank DP so chat starts immediately without failing
      const femaleNames = [
        'priya', 'sarah', 'emily', 'jessica', 'maya', 'chloe', 'jordan',
        'olivia', 'emma', 'sophia', 'ananya', 'pooja', 'sneha', 'neha', 'riya', 'aanya'
      ];
      const isFemale = femaleNames.some((f) => displayName.toLowerCase().includes(f)) || (cleanId.length % 2 === 0);
      const numericDigits = cleanId.replace(/\D/g, '');
      const seedNum = numericDigits ? parseInt(numericDigits, 10) : cleanId.length * 17;

      const guestPeer: VideoPartner = {
        id: `user-${cleanId.replace(/[^a-zA-Z0-9]/g, '')}-${Date.now()}`,
        userId: cleanId,
        name: displayName,
        age: 20 + (Math.abs(seedNum) % 8),
        gender: isFemale ? 'female' : 'male',
        country: 'Global',
        countryFlag: '🌐',
        city: 'Online',
        avatar: '', // blank DP as per design preference
        bio: `Active on QuickChat`,
        interests: ['Social', 'Direct Chat', 'Live Video'],
        isOnline: true
      };

      // Register profile into registry for cross-session and cross-tab lookup
      registerKnownUser({
        userId: guestPeer.userId,
        name: guestPeer.name,
        gender: guestPeer.gender,
        avatar: guestPeer.avatar,
        city: guestPeer.city,
        country: guestPeer.country,
        countryFlag: guestPeer.countryFlag,
        age: guestPeer.age
      });

      return guestPeer;
    },
    [conversations, currentUser]
  );

  // Start direct conversation with User ID or Username (Instantly connects & opens chat)
  const startConversationWithUser = useCallback(
    async (
      targetUserIdOrPartner: string | VideoPartner
    ): Promise<{ success: boolean; message: string; conv?: Conversation }> => {
      let partner: VideoPartner | null = null;
      if (typeof targetUserIdOrPartner === 'string') {
        const parsed = parseUserSearchQuery(targetUserIdOrPartner);
        const cleanTarget = parsed.normalizedId;
        const targetName = parsed.displayName;

        if (
          currentUser &&
          (cleanTarget === currentUser.uniqueUserId.toUpperCase() ||
            cleanTarget.replace('#', '') === currentUser.uniqueUserId.replace('#', '').toUpperCase() ||
            targetName.toLowerCase() === currentUser.name.toLowerCase())
        ) {
          return {
            success: false,
            message: 'You entered your own User ID/Username! Enter another user (e.g. #USER8555, Priya).'
          };
        }

        // Fast check: If conversation already exists, immediately trigger onSnapshot for combined roomId and open it
        const existing = conversations.find(
          (c) =>
            c.partnerUserId.toUpperCase() === cleanTarget ||
            c.partnerUserId.replace('#', '').toUpperCase() === cleanTarget.replace('#', '') ||
            c.partnerName.toLowerCase() === targetName.toLowerCase() ||
            c.partnerName.toLowerCase().includes(targetName.toLowerCase())
        );

        if (existing) {
          console.log(`[AppContext] User entered ID ${cleanTarget}, found existing conversation. Immediately triggering onSnapshot for combined room.`);
          attachChatRoomListener(existing.partnerUserId);
          setActiveConversation(existing);
          setActiveTab('chat');
          return {
            success: true,
            message: `Opened conversation with ${existing.partnerName} (${existing.partnerUserId})`,
            conv: existing
          };
        }

        partner = await searchPartnerByUserId(targetUserIdOrPartner);
      } else {
        partner = targetUserIdOrPartner;
      }

      if (!partner) {
        const inputId = typeof targetUserIdOrPartner === 'string' ? targetUserIdOrPartner.trim() : '';
        return {
          success: false,
          message: `Unable to connect to user "${inputId}". Please enter a valid User ID or Username.`
        };
      }

      // Check if conversation already exists by partner.userId
      const existing = conversations.find(
        (c) =>
          c.partnerUserId.toUpperCase() === partner!.userId.toUpperCase() ||
          c.partnerUserId.replace('#', '').toUpperCase() === partner!.userId.replace('#', '').toUpperCase()
      );

      if (existing) {
        console.log(`[AppContext] User entered ID ${partner.userId}, found existing conversation. Immediately triggering onSnapshot for combined room.`);
        attachChatRoomListener(existing.partnerUserId);
        setActiveConversation(existing);
        setActiveTab('chat');
        return {
          success: true,
          message: `Opened conversation with ${existing.partnerName} (${existing.partnerUserId})`,
          conv: existing
        };
      }

      // 2. Immediately trigger onSnapshot for that combined roomId
      console.log(`[AppContext] User entered ID ${partner.userId}. Immediately triggering onSnapshot for combined roomId.`);
      attachChatRoomListener(partner.userId);

      // Create new chat session cleanly without fake simulated greeting
      const newConv: Conversation = {
        id: `conv-${partner.userId.replace(/[^a-zA-Z0-9]/g, '')}-${Date.now()}`,
        partnerId: partner.id,
        partnerUserId: partner.userId,
        partnerName: partner.name,
        partnerAvatar: partner.avatar || '',
        partnerGender: partner.gender,
        partnerOnline: partner.isOnline ?? true,
        partnerFlag: partner.countryFlag || '🌐',
        lastMessage: 'Direct chat opened',
        lastMessageTime: 'Just now',
        unreadCount: 0,
        messages: []
      };

      setConversations((prev) => [
        newConv,
        ...prev.filter(
          (c) =>
            c.partnerUserId.toUpperCase() !== newConv.partnerUserId.toUpperCase() &&
            c.partnerUserId.replace('#', '').toUpperCase() !== newConv.partnerUserId.replace('#', '').toUpperCase()
        )
      ]);
      setActiveConversation(newConv);
      setActiveTab('chat');

      // Fetch real messages history from Firestore 'chats/${chatRoomDocId}/messages'
      const db = getFirebaseDb();
      if (db && currentUser) {
        const chatRoomDocId = getChatRoomDocId(currentUser.uniqueUserId, partner.userId);
        getDocs(
          query(
            collection(db, 'chats', chatRoomDocId, 'messages'),
            orderBy('timestamp', 'asc'),
            limit(50)
          )
        )
          .then((snap) => {
            if (!snap.empty) {
              const loadedMsgs: ChatMessage[] = snap.docs.map((d) => {
                const data = d.data() as RealtimeChatMessage;
                return {
                  id: data.id,
                  senderId: data.senderId,
                  recipientId: data.recipientId,
                  text: data.text,
                  timestamp:
                    data.timeString ||
                    new Date(data.timestamp).toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit'
                    }),
                  senderName: data.senderName,
                  isMine: isSameOrNormalizedUser(data.senderId, currentUser.uniqueUserId),
                  mediaType: data.mediaType,
                  mediaUrl: data.mediaUrl,
                  mediaName: data.mediaName
                };
              });
              setConversations((prev) =>
                prev.map((c) =>
                  c.partnerUserId === partner!.userId
                    ? {
                        ...c,
                        messages: loadedMsgs,
                        lastMessage: loadedMsgs[loadedMsgs.length - 1]?.text || c.lastMessage
                      }
                    : c
                )
              );
              setActiveConversation((prev) =>
                prev && prev.partnerUserId === partner!.userId
                  ? { ...prev, messages: loadedMsgs }
                  : prev
              );
            }
          })
          .catch((err) => {
            console.error('[Firestore Error] Failed to fetch message history from chats path:', err);
          });
      }

      return {
        success: true,
        message: `Connected with ${newConv.partnerName} (${newConv.partnerUserId}) for live chat!`,
        conv: newConv
      };
    },
    [conversations, currentUser, searchPartnerByUserId]
  );

  // Start Random Text Chat (100% Real P2P - NEVER synthesizes a bot)
  const startRandomTextChat = useCallback(
    async (): Promise<{ success: boolean; message: string; conv?: Conversation }> => {
      if (!currentUser) {
        return { success: false, message: 'Please sign in to start chatting.' };
      }

      // 1. Check existing conversations with real peers
      if (conversations.length > 0) {
        const existingConv = conversations[0];
        setActiveConversation(existingConv);
        setActiveTab('chat');
        return {
          success: true,
          message: `Opened conversation with ${existingConv.partnerName}`,
          conv: existingConv
        };
      }

      // 2. Check for waiting real peer in queue
      const peer = await findRandomRealWaitingPeer(currentUser.uniqueUserId);
      if (peer) {
        const realPartner: VideoPartner = {
          id: `user-${peer.userId}`,
          userId: peer.userId,
          name: peer.name,
          age: peer.age || 23,
          gender: peer.gender,
          country: peer.country || 'Global',
          countryFlag: peer.countryFlag || '🌐',
          city: peer.city || 'Online',
          avatar: peer.avatar || '',
          bio: 'Real peer on QuickChat',
          interests: ['Social', 'Chat'],
          isOnline: true
        };
        return startConversationWithUser(realPartner);
      }

      // 3. No real peer available - NEVER synthesize a bot!
      return {
        success: false,
        message:
          'No other online users are currently in the chat queue. Pure 100% real P2P only. You can start a Video Match or invite a friend with your User ID!'
      };
    },
    [conversations, currentUser, startConversationWithUser]
  );

  // Send message in active conversation (100% Real peer messaging - NO bot simulations)
  const sendMessage = useCallback(
    (convId: string, text: string, media?: { type: 'image' | 'video'; url: string; name?: string }) => {
      const trimmed = text.trim();
      if (!trimmed && !media) return;

      const summaryText = trimmed || (media?.type === 'video' ? '📹 Sent a video' : '📷 Sent a photo');

      // Determine target partner's user ID from conversation
      const targetConv = conversations.find((c) => c.id === convId) || (activeConversation?.id === convId ? activeConversation : null);
      const targetPartnerUserId = targetConv?.partnerUserId;

      const newMsg: ChatMessage = {
        id: `m-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
        senderId: currentUser?.uniqueUserId || 'current-user',
        recipientId: targetPartnerUserId || convId,
        text: trimmed,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        senderName: 'You',
        isMine: true,
        mediaType: media?.type,
        mediaUrl: media?.url,
        mediaName: media?.name
      };

      setConversations((prev) =>
        prev.map((c) => {
          if (c.id === convId) {
            return {
              ...c,
              lastMessage: summaryText,
              lastMessageTime: 'Just now',
              messages: [...c.messages, newMsg]
            };
          }
          return c;
        })
      );

      if (activeConversation && activeConversation.id === convId) {
        setActiveConversation((prev) =>
          prev ? { ...prev, lastMessage: summaryText, messages: [...prev.messages, newMsg] } : null
        );
      }

      // Dispatch real-time cross-tab BroadcastChannel, localStorage, and Firestore message
      if (currentUser && targetPartnerUserId) {
        sendRealtimeMessage({
          id: newMsg.id,
          senderId: currentUser.uniqueUserId,
          senderName: currentUser.name,
          senderAvatar: currentUser.avatar,
          recipientId: targetPartnerUserId,
          text: trimmed,
          mediaType: media?.type,
          mediaUrl: media?.url,
          mediaName: media?.name,
          timestamp: Date.now(),
          timeString: newMsg.timestamp
        }).catch((err) => {
          console.error('[Messaging Error] Failed to send real-time message:', err);
        });
      }
    },
    [currentUser, activeConversation, conversations]
  );

  // Delete Conversation
  const deleteConversation = useCallback((convId: string) => {
    setConversations((prev) => prev.filter((c) => c.id !== convId));
    setActiveConversation((prev) => (prev?.id === convId ? null : prev));
  }, []);

  // Block User
  const blockUser = useCallback((partnerUserId: string, partnerName?: string) => {
    const cleanId = partnerUserId.trim().toUpperCase();
    setBlockedUserIds((prev) => {
      if (prev.includes(cleanId)) return prev;
      return [...prev, cleanId];
    });

    // Remove any existing conversation with this user
    setConversations((prev) =>
      prev.filter((c) => c.partnerUserId.trim().toUpperCase() !== cleanId)
    );
    setActiveConversation((prev) =>
      prev?.partnerUserId.trim().toUpperCase() === cleanId ? null : prev
    );
    console.info(`[Safety] User ${partnerUserId} (${partnerName || 'Unknown'}) blocked.`);
  }, []);

  // Report User
  const reportUser = useCallback((partnerUserId: string, reason: string, partnerName?: string) => {
    try {
      const reports = JSON.parse(localStorage.getItem('quickchat_user_reports_v2') || '[]');
      reports.push({
        reportedUserId: partnerUserId,
        reportedUserName: partnerName,
        reason,
        reportedAt: new Date().toISOString()
      });
      localStorage.setItem('quickchat_user_reports_v2', JSON.stringify(reports));
    } catch {
      // ignore
    }
    console.info(`[Safety] User ${partnerUserId} (${partnerName || 'Unknown'}) reported: ${reason}`);
  }, []);

  // Check if User is Blocked
  const isUserBlocked = useCallback(
    (userId: string) => {
      const cleanId = userId.trim().toUpperCase();
      return blockedUserIds.includes(cleanId);
    },
    [blockedUserIds]
  );

  return (
    <AppContext.Provider
      value={{
        isAuthenticated,
        currentUser,
        loginWithGoogle,
        loginAsGuest,
        logout,
        activeTab,
        setActiveTab,
        addCoins,
        deductCoins,
        spinCount,
        spinsRemaining,
        spinWheel,
        prepareSpin,
        commitSpinReward,
        canSpin,
        femalePass,
        isFemalePassActive,
        femalePassRemainingDays,
        unlockFemalePass,
        femalePassCost: FEMALE_PASS_COST,
        resetSpinCounterForTesting,
        genderFilter,
        setGenderFilter,
        currentVideoPartner,
        isCallConnecting,
        isCallActive,
        currentCallRoom,
        agoraChannel,
        startVideoMatch,
        skipToNextPartner,
        endVideoCall,
        insufficientCoinsModal,
        setInsufficientCoinsModal,
        conversations,
        activeConversation,
        setActiveConversation: selectActiveConversation,
        deleteConversation,
        blockUser,
        reportUser,
        blockedUserIds,
        isUserBlocked,
        isPartnerTyping,
        sendMessage,
        startConversationWithUser,
        searchPartnerByUserId,
        startRandomTextChat,
        updateUniqueUserId,
        updateProfileName,
        updateProfileAvatar,
        removeProfileAvatar
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
