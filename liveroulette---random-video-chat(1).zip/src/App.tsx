import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { AuthScreen } from './components/AuthScreen';
import { TopBar } from './components/TopBar';
import { BottomNavBar } from './components/BottomNavBar';
import { VideoCallTab } from './components/VideoCallTab';
import { ChattingTab } from './components/ChattingTab';
import { SpinAndEarnTab } from './components/SpinAndEarnTab';
import { ProfileTab } from './components/ProfileTab';
import { GetMoreCoinsModal } from './components/GetMoreCoinsModal';

const MainAppContent: React.FC = () => {
  const { isAuthenticated, activeTab } = useApp();

  // 1. Initial Authentication Screen if not logged in
  if (!isAuthenticated) {
    return <AuthScreen />;
  }

  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100 flex flex-col font-sans select-none antialiased">
      {/* 2. Top Bar: Always display current Coin Balance on top-right */}
      <TopBar />

      {/* Main Content Area switching between the 4 Tabs */}
      <main className="flex-1 flex flex-col overflow-y-auto">
        {activeTab === 'video' && <VideoCallTab />}
        {activeTab === 'chat' && <ChattingTab />}
        {activeTab === 'spin' && <SpinAndEarnTab />}
        {activeTab === 'profile' && <ProfileTab />}
      </main>

      {/* 3. Bottom Navigation Bar: 4 Tabs */}
      <BottomNavBar />

      {/* "Get More Coins" Modal when female call is selected and balance < 10,000 */}
      <GetMoreCoinsModal />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <MainAppContent />
    </AppProvider>
  );
}
